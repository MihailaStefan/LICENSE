<?php
session_start();
$error = array();

require "mail.php";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
 
    $servername = "localhost";
    $username = "id21132511_root";
    $password = "Mihaila.stefan10";
    $dbname = "id21132511_db_students_etti";

    $con = new mysqli($servername, $username, $password, $dbname);

    if ($con->connect_error) {
        die("Conexiune eșuată: " . $con->connect_error);
    }

    if (isset($_POST['email'])) {

        $email = $_POST['email'];
        
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error[] = "Please enter a valid email";
        } elseif (!valid_email($con, $email)) {
            $error[] = "That email was not found";
        } else {
            $_SESSION['forgot']['email'] = $email;
            send_email($email);
            header("Location: forgot.php?mode=enter_code"); // Redirecționează către introducerea codului
            exit();
        }
    } elseif (isset($_POST['code'])) {
        $code = $_POST['code'];
        $result = is_code_correct($code, $con);

        if ($result == "The code is correct") {

            $_SESSION['forgot']['code'] = $code;
            header("Location: forgot.php?mode=enter_password");
            exit();
        } else {
            $error[] = $result;
        }
    } elseif (isset($_POST['password'])) {
        $password = $_POST['password'];
        $password2 = $_POST['password2'];

        if ($password !== $password2) {
            $error[] = 'Passwords do not match';
        }elseif(!isset($_SESSION['forgot']['email']) || !isset($_SESSION['forgot']['code'])){
            header("Location: forgot.php");
        }else{
            save_password($password, $con);
            if(isset($_SESSION['forgot'])){
                unset($_SESSION['forgot']);
            }

            header("Location: index.html?successMsg=The password has been successfully changed. You can now log in.");
            exit();
        }
    }
}

function send_email($email) {
    global $con;

    $expire = time() + (30 * 1);
    $code = rand(100000,999999);
    $email = addslashes($email);

    $query = "INSERT INTO codes (email, code, expire) VALUES ('$email', '$code', '$expire')";
    mysqli_query($con, $query);

    send_mail($email,'Resetare parola',"Codul tau este " . $code);
}

function save_password($password, $con) {
    //$password = password_hash($password, PASSWORD_DEFAULT);
    $email = addslashes($_SESSION['forgot']['email']);

    $query = "UPDATE login SET password = '$password' WHERE email = '$email' LIMIT 1";
    mysqli_query($con, $query);
}

function valid_email($con, $email) {
    $email = addslashes($email);

    $query = "SELECT * FROM users WHERE email = '$email' LIMIT 1";
    $result = mysqli_query($con, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        return true;
    }

    return false;
}

function is_code_correct($code, $con) {
    $code = addslashes($code);
    $expire = time();
    $email = addslashes($_SESSION['forgot']['email']);

    $query = "SELECT * FROM codes WHERE code = '$code' && email = '$email' ORDER BY id DESC LIMIT 1";
    $result = mysqli_query($con, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        if ($row['expire'] > $expire) {
            return "The code is correct";
        } else {
            return "The code is expired";
        }
    } else {
        return "The code is incorrect";
    }
}
?>
<!doctype html>
<html lang="en">
<head>
  <title>Forgot password</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" href="forgot.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
  <style>
    .icon {
      font-family: FontAwesome;
    }
  </style>
</head>
<body>
  <div class="wrapper">
    <div class="container">
      <div class="title-section">
        <h2 class="title">Reset password</h2>
      </div>
      <div class="forgot">
        <?php
          $mode = isset($_GET['mode']) ? $_GET['mode'] : "enter_email";

          switch ($mode) {
            case 'enter_email':
              ?>
                <p class="paraf" style="color: white;">Enter your email address so we can send you helpful instructions to reset your password.
                <br><br>
                <form action="forgot.php" method="post" class="from">
                <div class="input-group">
                  <label for="" class="label-title">Enter your e-mail</label>
                  <span style="font-size: 12px;color:red">
                  <?php
                    foreach ($error as $err) {
    
                        echo $err . "<br>";
                    }
                  ?>
                  </span>
                  <input type="email" name="email" required="" placeholder="Enter your e-mail">
                  <span class="icon">&#9993;</span>
                </div>
                <div class="link"><a href="index.html">Login</a></div>
                <button type="submit" class="button">Send reset e-mail</button>
              </form>
              <?php
              break;
            
            case 'enter_code':
              ?>
              <form action="forgot.php?mode=enter_code" method="post" class="from">
                <div class="input-group">
                  <label for="" class="label-title">Enter the code sent to your email</label>
                  <span style="font-size: 12px;color:red">
                  <?php
                    foreach ($error as $err) {
    
                        echo $err . "<br>";
                    }
                  ?>
                  <input type="text" name="code" required="" placeholder="Enter the code">
                  
                </div>
                <button type="submit" class="button">Verify code</button>
              </form>
              <?php
              break;
            
            case 'enter_password':
              ?>
              <form action="forgot.php?mode=enter_password" method="post" class="from">
                <div class="input-group">
                <span style="font-size: 12px;color:red">
                  <?php
                    foreach ($error as $err) {
                        
                        echo $err . "<br>";
                    }
                  ?>
                  <label for="" class="label-title">Enter your new password</label>
                  <input type="password" name="password" required="" placeholder="Password">
                 
                </div>
                <div class="input-group">
                  <label for="" class="label-title">Retype your new password</label>
                  <input type="password" name="password2" required="" placeholder="Retype Password">
            
                </div>
                <button type="submit" class="button">Reset password</button>
                <div id="successMessage" style="display: none;"></div>
                
              </form>
              <?php
              break;
            
            default:
                
              break;
          }
        ?>
      </div>
    </div>
  </div>
</body>
</html>