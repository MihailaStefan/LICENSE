<?php
// Verificăm dacă formularul de login a fost trimis
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Conexiune la baza de date
    $servername = "localhost";
    $username = "id21132511_root";
    $password = "Mihaila.stefan10";
    $dbname = "id21132511_db_students_etti";

    $conn = new mysqli($servername, $username, $password, $dbname);

    // Verificăm conexiunea
    if ($conn->connect_error) {
        die("Conexiune eșuată: " . $conn->connect_error);
    }
    // Obținem datele introduse în formular
    $username = $_POST["username"];
    $password = $_POST["password"];

    // Query pentru a verifica autentificarea
    $sql = "SELECT * FROM login WHERE username = '$username' AND password = '$password'";
    $result = $conn->query($sql);

    // Verificăm dacă s-a găsit un utilizator cu aceste date
    if ($result->num_rows > 0) {
        // Autentificare reușită
        // Porniți sesiunea și stocați informațiile relevante despre utilizator
        session_start();
        $_SESSION["username"] = $username;
       
        // Redirecționați către pagina principală
        header("Location: main.html");
        exit();
    } else {
        // Autentificare eșuată
        // Redirecționați înapoi la pagina de login cu mesaj de eroare
        header("Location: index.html?error=1");
        exit();
    }

    // Închidem conexiunea la baza de date
    $conn -> close();
}
?>
