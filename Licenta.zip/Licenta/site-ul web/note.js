const email = "stefan_stefan120@yahoo.com";

const shouldNotBeRendered = ["email"];

const renderTable = (data) => {
  const tableBody = document.getElementById("table-body");

  if (data && data.length) {
    // construim coloanele pe baza primului element
    const th = document.createElement("div");
    th.classList.add("th");
    tableBody.append(th);

    Object.keys(data[0]).forEach((coloana) => {
      if (!shouldNotBeRendered.some((el) => el === coloana)) {
        const td = document.createElement("div");
        td.classList.add("td", "header");
        th.append(td);
        td.textContent = coloana.charAt(0).toUpperCase() + coloana.slice(1);
      }
    });

    // consturim randurile
    data.forEach((row) => {
      const tr = document.createElement("div");
      tr.classList.add("tr", "show");
      tr.id = row.materie;
      tableBody.append(tr);

      Object.entries(row).forEach(([key, value]) => {
        if (!shouldNotBeRendered.some((el) => el === key)) {
          const td = document.createElement("div");
          td.classList.add("td", "row");
          tr.append(td);
          td.textContent = value;
        }
      });
    });
  }
};

const search = () => {
  const input = document.getElementById("search-input");

  if (input) {
    const rows = document
      .getElementById("table-body")
      .getElementsByClassName("tr");

    let foundOne = false;
    for (let row of rows) {
      if (
        !row.id.toLocaleLowerCase().includes(input.value.toLocaleLowerCase())
      ) {
        row.classList.remove("show");
      } else {
        row.classList.add("show");
        foundOne = true;
      }
    }

    const noData = document.getElementById("no-data-text");
    if (!foundOne) {
      noData.classList.add("show");
    } else {
      noData.classList.remove("show");
    }
  }
};

const searchBtn = document.getElementById("search-button");
searchBtn.addEventListener("click", search, false);

let tableData = [];
window.addEventListener("load", () => {
  const loader = document.getElementById("loader");
  const noData = document.getElementById("no-data-text");
  loader.classList.toggle("show");

  fetch("https://64ef80b6219b3e2873c494a7.mockapi.io/api/catalog/", {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
    },
  })
    .then((response) => response.json())
    .then((data) => {
      loader.classList.toggle("show");
      try {
        renderTable(data);
        tableData = data;
        // salvam sa avem datele si pt search
      } catch (err) {
        console.log(err);
      }
    })
    .catch((err) => {
      loader.classList.toggle("show");
    })
    .finally((data) => {
      if (!tableData.length) {
        noData.classList.add("show");
      } else {
        noData.classList.remove("show");
      }
    });
});