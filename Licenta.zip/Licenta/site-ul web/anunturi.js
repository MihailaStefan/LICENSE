const button1 = document.getElementById("anunturi-btn");
const content1 = document.getElementById("anunturi-text");
const container1 = document.getElementById("anunturi-col1");

const onClick = (container, btn, content) => {
  container.classList.toggle("expanded");
  content.classList.toggle("show");
  if (content.classList.contains("show")) {
    btn.textContent = "Citeste mai putin";
  } else {
    btn.textContent = "Citeste mai mult";
  }
};

button1.addEventListener("click", () => onClick(container1, button1, content1));

const button2 = document.getElementById("anunturi-btn2");
const content2 = document.getElementById("anunturi-text2");
const container2 = document.getElementById("anunturi-col2");

button2.addEventListener("click", () => onClick(container2, button2, content2));

const button3 = document.getElementById("anunturi-btn3");
const content3 = document.getElementById("anunturi-text3");
const container3 = document.getElementById("anunturi-col3");

button3.addEventListener("click", () => onClick(container3, button3, content3));

const button4 = document.getElementById("anunturi-btn4");
const content4 = document.getElementById("anunturi-text4");
const container4 = document.getElementById("anunturi-col4");

button4.addEventListener("click", () => onClick(container4, button4, content4));

const button5 = document.getElementById("anunturi-btn5");
const content5 = document.getElementById("anunturi-text5");
const container5 = document.getElementById("anunturi-col5");

button5.addEventListener("click", () => onClick(container5, button5, content5));

const button6 = document.getElementById("anunturi-btn6");
const content6 = document.getElementById("anunturi-text6");
const container6 = document.getElementById("anunturi-col6");

button6.addEventListener("click", () => onClick(container6, button6, content6));