// fetch("/imagini/grupe").then(
//   async (res) => {
//     console.log(await res.blob());
//   },
//   (err) => console.log(err)
// );

let groupHrefs = {};
let profHrefs = {};
const loadImages = (path) => {
  var xhr = new XMLHttpRequest();
  xhr.open("GET", `/imagini/${path}`, true);
  xhr.responseType = "document";
  xhr.onload = () => {
    if (xhr.status === 200) {
      var elements = xhr.response.getElementsByTagName("a");

      for (let x of elements) {
        if (x.href.match(".png")) {
          if (path === "grupe") {
            groupHrefs = {
              ...groupHrefs,
              [Object.keys(groupHrefs).length + 1]: x.href,
            };
          } else if (path === "profesori") {
            profHrefs = {
              ...profHrefs,
              [Object.keys(profHrefs).length + 1]: x.href,
            };
          }
        }
      }
    } else {
      alert("Request failed. Returned status of " + xhr.status);
    }
  };
  xhr.send();
};

loadImages("grupe", groupHrefs);
loadImages("profesori", profHrefs);

var groupSelect = document.getElementById("groupSelect");
var profSelect = document.getElementById("profSelect");
var groupImage = document.getElementById("groupImage");
var profImage = document.getElementById("profImage");

groupSelect.addEventListener("change", (e) => {
  // am pus plus in fata ca sa faca conversia de la string la number
  let selectedValue = +e.target.value;

  if (selectedValue !== 0) {
    groupImage.src = groupHrefs[selectedValue];
    profImage.src = "";
    profSelect.options[0].selected = true;
  } else {
    groupImage.src = ""; // Golește sursa imaginii
  }
});

profSelect.addEventListener("change", (e) => {
  let selectedValue = +e.target.value;

  if (selectedValue !== 0) {
    profImage.src = profHrefs[selectedValue];
    groupImage.src = "";
    groupSelect.options[0].selected = true;
  } else {
    profImage.src = ""; // Golește sursa imaginii
  }
});